plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.neondrift.game"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.neondrift.game"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "0.2.0"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("neondrift.keystore")
            storePassword = "neondrift"
            keyAlias = "neondrift"
            keyPassword = "neondrift"
        }
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.google.android.gms:play-services-auth:21.2.0")
}
