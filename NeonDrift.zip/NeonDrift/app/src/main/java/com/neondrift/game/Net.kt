package com.neondrift.game

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import kotlin.random.Random

class Remote(val id: Int) {
    @Volatile var name = "PLAYER"
    @Volatile var email = ""
    @Volatile var car = 0
    @Volatile var paint = 0
    @Volatile var tx = 0f
    @Volatile var tz = 0f
    @Volatile var tpsi = 0f
    @Volatile var u = 0f
    @Volatile var steer = 0f
    @Volatile var slip = 0f
    @Volatile var last = 0L
    var x = 0f; var z = 0f; var psi = 0f; var spin = 0f; var inited = false
}

/** LAN multiplayer over UDP (same Wi-Fi or phone hotspot). Host = relay; clients send state to host. */
class Net(private val g: Game) {
    val remotes = ConcurrentHashMap<Int, Remote>()
    @Volatile var mode = 0           // 0 off, 1 host, 2 client
    @Volatile var status = "OFFLINE"
    val myId = Random.nextInt()
    @Volatile var localIp = ""
    private var joinIp = ""
    @Volatile private var running = false
    private var sock: DatagramSocket? = null
    private val clients = ConcurrentHashMap<Int, InetSocketAddress>()
    private val banned = ConcurrentHashMap<Int, Long>()
    @Volatile private var pendingMsg: String? = null

    fun host() { stop(); mode = 1; start() }
    fun join(ip: String) { stop(); joinIp = ip.trim(); mode = 2; start() }

    fun stop() {
        running = false
        try { sock?.close() } catch (_: Exception) {}
        sock = null
        remotes.clear(); clients.clear()
        mode = 0; status = "OFFLINE"
    }

    fun kick(id: Int) {
        if (mode != 1 || id == 0) return
        banned[id] = System.currentTimeMillis() + 60000L
        remotes.remove(id); clients.remove(id)
    }

    fun broadcast(msg: String) { if (mode == 1) { pendingMsg = msg.take(60); g.toast("SENT: $msg") } }

    private fun start() {
        running = true
        Thread { loop() }.also { it.isDaemon = true }.start()
    }

    private fun loop() {
        try {
            val s = DatagramSocket(null)
            s.reuseAddress = true
            if (mode == 1) s.bind(InetSocketAddress(PORT)) else s.bind(InetSocketAddress(0))
            s.soTimeout = 25
            sock = s
            localIp = findIp()
            val target = if (mode == 2) InetSocketAddress(InetAddress.getByName(joinIp), PORT) else null
            status = if (mode == 1) "HOSTING  $localIp" else "JOINING $joinIp ..."
            val buf = ByteArray(2048)
            val pk = DatagramPacket(buf, buf.size)
            var lastSend = 0L
            while (running) {
                try { pk.length = buf.size; s.receive(pk); handle(pk) } catch (_: SocketTimeoutException) {}
                val now = System.currentTimeMillis()
                if (now - lastSend >= 50) {
                    lastSend = now
                    send(s, target)
                    cleanup(now)
                }
            }
            s.close()
        } catch (e: Exception) {
            status = "NET ERROR: ${e.message}"; running = false; mode = 0
        }
    }

    private fun mine(bb: ByteBuffer) = put(bb, myId, g.name, g.carIdx, g.paintIdx, g.car.x, g.car.z, g.car.psi, g.car.u, g.car.steerAngle, g.car.rearSlip)

    private fun put(bb: ByteBuffer, id: Int, name: String, car: Int, paint: Int, x: Float, z: Float, psi: Float, u: Float, steer: Float, slip: Float) {
        bb.putInt(id); bb.put(car.toByte()); bb.put(paint.toByte())
        bb.putFloat(x); bb.putFloat(z); bb.putFloat(psi); bb.putFloat(u); bb.putFloat(steer)
        bb.put((slip.coerceIn(0f, 1f) * 255).toInt().toByte())
        val nb = name.toByteArray(Charsets.US_ASCII)
        for (i in 0 until 12) bb.put(if (i < nb.size) nb[i] else 32.toByte())
    }

    private fun send(s: DatagramSocket, target: InetSocketAddress?) {
        val bb = ByteBuffer.allocate(1500)
        if (mode == 2 && target != null) {
            bb.put(MAGIC); bb.put(1); mine(bb)
            s.send(DatagramPacket(bb.array(), bb.position(), target))
        } else if (mode == 1) {
            status = "HOSTING  $localIp   (${clients.size} joined)"
            val msg = pendingMsg
            for ((cid, addr) in clients) {
                bb.clear()
                bb.put(MAGIC); bb.put(2)
                val others = remotes.values.filter { it.id != cid }
                bb.put((others.size + 1).toByte())
                mine(bb)
                for (r in others) put(bb, r.id, r.name, r.car, r.paint, r.tx, r.tz, r.tpsi, r.u, r.steer, r.slip)
                s.send(DatagramPacket(bb.array(), bb.position(), addr))
                if (msg != null) {
                    bb.clear(); bb.put(MAGIC); bb.put(4)
                    val mb = msg.toByteArray(Charsets.US_ASCII); bb.put(mb.size.toByte()); bb.put(mb)
                    s.send(DatagramPacket(bb.array(), bb.position(), addr))
                }
            }
            pendingMsg = null
        }
    }

    private fun readState(bb: ByteBuffer, now: Long): Int {
        val id = bb.getInt()
        val car = bb.get().toInt(); val paint = bb.get().toInt()
        val x = bb.getFloat(); val z = bb.getFloat(); val psi = bb.getFloat(); val u = bb.getFloat(); val st = bb.getFloat()
        val slip = (bb.get().toInt() and 255) / 255f
        val nb = ByteArray(12); bb.get(nb)
        if (id == myId) return id
        val ban = banned[id]
        if (ban != null && ban > now) return id
        val r = remotes.getOrPut(id) { Remote(id) }
        r.car = car.coerceIn(0, CARS.size - 1); r.paint = paint.coerceIn(0, PAINTS.size - 1)
        r.tx = x; r.tz = z; r.tpsi = psi; r.u = u; r.steer = st; r.slip = slip
        r.name = String(nb, Charsets.US_ASCII).trim(); r.last = now
        return id
    }

    private fun handle(pk: DatagramPacket) {
        if (pk.length < 3) return
        val bb = ByteBuffer.wrap(pk.data, 0, pk.length)
        if (bb.get() != MAGIC) return
        val type = bb.get().toInt()
        val now = System.currentTimeMillis()
        if (type == 1 && mode == 1 && pk.length >= 2 + STATE) {
            val id = readState(bb, now)
            val ban = banned[id]
            if (ban == null || ban < now) clients[id] = InetSocketAddress(pk.address, pk.port)
        } else if (type == 2 && mode == 2) {
            val n = bb.get().toInt()
            for (i in 0 until n) { if (bb.remaining() < STATE) break; readState(bb, now) }
            status = "CONNECTED  ${remotes.size + 1} players"
        } else if (type == 4 && mode == 2) {
            val l = bb.get().toInt() and 255
            if (bb.remaining() >= l) { val b = ByteArray(l); bb.get(b); g.toast("HOST: " + String(b, Charsets.US_ASCII)) }
        }
    }

    private fun cleanup(now: Long) {
        for (r in remotes.values) if (now - r.last > 4000) { remotes.remove(r.id); clients.remove(r.id) }
        for ((id, t) in banned) if (t < now) banned.remove(id)
    }

    private fun findIp(): String {
        try {
            var fallback = ""
            for (ni in NetworkInterface.getNetworkInterfaces()) for (a in ni.inetAddresses) {
                if (a.isLoopbackAddress || a !is Inet4Address) continue
                if (a.isSiteLocalAddress) return a.hostAddress ?: ""
                fallback = a.hostAddress ?: ""
            }
            return fallback
        } catch (_: Exception) { return "" }
    }

    companion object {
        const val PORT = 47777
        const val MAGIC: Byte = 0x4E
        const val STATE = 4 + 1 + 1 + 20 + 1 + 12
    }
}
