package com.neondrift.game

import kotlin.math.*

/**
 * CarX-style bicycle model:
 * - Pacejka magic formula tyres
 * - Friction circle (combined slip)
 * - Weight transfer front/rear + left/right
 * - Proper handbrake rear-lock
 * - Drift angle up to 80° without spinning
 */
class CarPhysics {
    // tunable per car
    var mass     = 1300f
    var torque   = 420f
    var muF      = 1.18f
    var muR      = 1.10f
    var nitroPower = 0.35f
    var gripMul  = 1f
    var rollRes  = 0f
    var powerMul = 1f
    var assist   = 1.05f   // counter-steer assist strength
    var ydamp    = 2.2f    // yaw damping

    // geometry (m)
    val a = 1.22f   // front axle to CG
    val b = 1.38f   // rear axle to CG
    private val h  = 0.52f   // CG height
    private val tw = 0.82f   // half track width
    private val iz = 1850f   // yaw inertia

    // state
    var x = 0f; var z = 0f; var psi = 0f
    var u = 0f; var v = 0f; var r = 0f   // body-frame: u=fwd v=lat r=yaw
    var ax = 0f; var ay = 0f
    var gear = 0; var rpm = 1000f
    var steerAngle = 0f
    var rearSlip  = 0f
    var frontSlip = 0f
    var wheelSpin = 0f
    var spinning  = false

    val speed: Float get() = sqrt(u * u + v * v)
    val beta:  Float get() = if (abs(u) > 1f) atan2(v, abs(u)) else 0f

    fun place(px: Float, pz: Float, heading: Float) {
        x = px; z = pz; psi = heading
        u = 0f; v = 0f; r = 0f; ax = 0f; ay = 0f; gear = 0; rpm = 1000f
        steerAngle = 0f; rearSlip = 0f; frontSlip = 0f; wheelSpin = 0f
    }

    /** Pacejka simplified: peak at alpha=atan(1/B), shape via C, scale D */
    private fun pacejka(alpha: Float, D: Float, B: Float = 9f, C: Float = 1.55f): Float {
        return -D * sin(C * atan(B * alpha - 0.2f * (B * alpha - atan(B * alpha))))
    }

    fun step(dt: Float, steerIn: Float, thr: Float, brk: Float, hb: Boolean, nitro: Boolean) {
        val G = 9.81f
        val L = a + b
        val au = abs(u)

        // --- weight transfer ---
        val Nf0 = mass * G * b / L
        val Nr0 = mass * G * a / L
        val dNx = mass * ax * h / L          // pitch: fwd accel loads rear
        val dNy = mass * ay * h / (2f * tw)  // roll:  lat accel loads outer
        val Nfl = (Nf0 - dNx) * 0.5f - dNy
        val Nfr = (Nf0 - dNx) * 0.5f + dNy
        val Nrl = (Nr0 + dNx) * 0.5f - dNy
        val Nrr = (Nr0 + dNx) * 0.5f + dNy
        val Nf  = (Nfl + Nfr).coerceAtLeast(mass * G * 0.08f)
        val Nr  = (Nrl + Nrr).coerceAtLeast(mass * G * 0.08f)

        // --- steering ---
        val dmax  = 0.58f / (1f + (au / 20f).pow(1.7f)) + 0.10f
        val bet   = if (u > 1f) atan2(v, u) else 0f
        val k     = assist * ((au - 3f) / 6f).coerceIn(0f, 1f)
        val delta = (steerIn * dmax + k * bet).coerceIn(-0.68f, 0.68f)
        steerAngle = delta

        // --- engine / gearbox ---
        val gears = floatArrayOf(3.6f, 2.5f, 1.85f, 1.45f, 1.15f, 0.95f)
        val fd = 3.7f; val rw = 0.315f
        val rpmRaw = max(1100f, au / rw * gears[gear] * fd * 60f / (2f * PI.toFloat()))
        if (rpmRaw > 7400f && gear < 5) gear++
        if (rpmRaw < 3100f && gear > 0) gear--
        val tqCurve = max(0.32f, 1f - ((rpmRaw - 5400f) / 4500f).pow(2))
        val tqNet   = torque * tqCurve * powerMul * (1f + nitroPower * if (nitro) 1f else 0f)
        var fxDem   = thr * tqNet * gears[gear] * fd * 0.88f / rw
        if (u < -0.5f) fxDem = thr * 4000f - brk * 3200f
        else if (u < 1f && brk > 0.2f && thr < 0.05f) fxDem = -brk * 3200f

        // --- tyre limits (friction circle) ---
        val muRe  = muR * gripMul * (if (hb) 0.28f else 1f)
        val muFe  = muF * gripMul
        val Dr    = muRe * Nr
        val Df    = muFe * Nf
        val fxMax = Dr * 0.96f
        var Fx    = fxDem.coerceIn(-fxMax, fxMax)
        spinning  = fxDem > fxMax * 1.05f && thr > 0.25f
        // lateral capacity reduced by driven force (friction circle)
        val DlatR = sqrt(max(Dr * Dr - Fx * Fx, (0.28f * Dr).pow(2)))
        val DlatF = Df

        // --- slip angles ---
        val uu   = max(au, 0.6f)
        val alpF = atan2(v + a * r, uu) - delta
        val alpR = atan2(v - b * r, uu)

        val Ff = pacejka(alpF, DlatF)
        val Fr = pacejka(alpR, DlatR)

        // --- longitudinal braking ---
        var Fb = 0f
        if (brk > 0f && u > 0.5f)  Fb -= brk  * min(0.94f * mass * G, 10500f)
        if (hb   && u > 0.5f)       Fb -= 0.22f * Dr

        // --- drag + rolling resistance ---
        val sgn  = if (u > 0f) 1f else if (u < 0f) -1f else 0f
        val drag = 0.38f * u * au + (175f + rollRes * mass * 0.45f) * sgn * min(1f, au)

        // --- drift boost: throttle sustains slide ---
        var fxt = Fx + Fb - Ff * sin(delta) - drag
        if (thr > 0.45f && u > 7f && abs(bet) > 0.18f)
            fxt += mass * 1.15f * (abs(bet) / 0.55f).coerceAtMost(1f)

        // --- EOM ---
        val ud = fxt / mass + v * r
        val vd = (Fr + Ff * cos(delta)) / mass - u * r
        val rd = (a * Ff * cos(delta) - b * Fr) / iz - ydamp * r

        ax = 0.88f * ax + 0.12f * (fxt / mass)
        ay = 0.84f * ay + 0.16f * (vd + u * r)

        u += ud * dt; v += vd * dt; r += rd * dt
        psi += r * dt
        val s = sin(psi); val c = cos(psi)
        x   += (u * s + v * c) * dt
        z   += (u * c - v * s) * dt

        rpm = rpmRaw + if (spinning) 1600f else 0f
        val ws = if (spinning) max(u, 10f) else u
        wheelSpin += ws / rw * dt

        val moving = if (au > 2f) 1f else 0f
        rearSlip  = maxOf(abs(alpR) / 0.28f,
            if (spinning) 0.65f else 0f,
            if (hb) 0.95f else 0f).coerceIn(0f, 1f) * moving
        frontSlip = (abs(alpF) / 0.32f).coerceIn(0f, 1f) * moving
    }

    companion object {
        const val RW = 0.315f
    }
}
