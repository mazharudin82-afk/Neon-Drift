# Neon Drift (Phase 1)
Native Android 3D drift game: Kotlin + OpenGL ES 3.0. Package com.neondrift.game, minSdk 26.
Build: open in Android Studio, or use the GitHub Actions workflow.
Controls: touch buttons / tilt / keyboard (WASD, SPACE=drift, SHIFT=nitro, C=cam, R=reset, ESC=garage) / gamepad.
